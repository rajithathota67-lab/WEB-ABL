WEB DEVELOPMENT ACTIVITY-BASED LEARNING
Three selected case studies:
1. Personal Portfolio Website
2. College Information and Admissions Website
3. Healthy Food and Nutrition Website

HOW TO RUN:
1. Extract this ZIP file.
2. Open any project folder.
3. Double-click index.html, or open it with a browser.
4. Keep index.html and style.css in the same folder.

NOTES:
- Each project has separate HTML and CSS files.
- Replace sample details (such as email, education history and achievements) with your actual information.
- Images are loaded from Unsplash, so an internet connection is needed to display them.
- The college website is an educational sample; verify official course, fee and admission details with the university.
